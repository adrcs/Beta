#!/bin/bash

if [ "$#" -ne 2 ]; then
	echo "Usage updateFPGA <device> <filename>"
	exit 100
fi
echo "Flashing $1 to FPGA"
set -x

# program FPGA flash: timing when completed
time ./FPGAFlash -c "$1" -k -b 115200 -f "$2"
set +x
