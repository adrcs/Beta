src/comlib.o: src/comlib.c Include/comlib.h
Include/comlib.h:
