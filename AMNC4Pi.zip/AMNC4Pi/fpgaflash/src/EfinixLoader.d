src/EfinixLoader.o: src/EfinixLoader.c Include/EfinixLoader.h \
 Include/conio.h Include/comlib.h Include/frametypes.h src/conio.h
Include/EfinixLoader.h:
Include/conio.h:
Include/comlib.h:
Include/frametypes.h:
src/conio.h:
