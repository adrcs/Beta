//-------------------------------------------------------------------------------------------------
//
//  STM32C071 Efinix Serial to SPI Hex Loader 
//                                        
//  Copyright (C) 2025 HT-LAB  
//  https://github.com/htminuslab/Efinix_T20_Dev_Board                                                                                  
//
//  The frame format consist of 1 SYNC byte, 1 CMD/Sequence byte, 2^n databytes and 1 CRC8 byte
//  Sync is 0x7E 
//  CRC is CRC8 with Polynomial 0x07, Initial value 0x00, Final XOR 0x00
//
//  Compile using make under DOS (MingW64 gcc)
//
//-------------------------------------------------------------------------------------------------
//  Revision History:                                                        
//                                                                           
//  Date		Revision	Changes 
//  03-May-25   0.1         First version, upload to FPGA RAM
//  20-July-25  0.2         Added Flash support
//  Dual windows/linux version
//-------------------------------------------------------------------------------------------------
#include <sys/stat.h>
#include <sys/types.h>

#include "EfinixLoader.h"
#ifndef WIN32
#include "conio.h"
#endif

#define		FULL_CMD_SET			0			// set to 1 for full command set

// KISS Commands
#define KISS_FEND  			0xC0			// frame start/end
#define	KISS_CMD			0x0D			// update flash commnad
#define	KISS_FPGA			0xE8			// flash update command

//-------------------------------------------------------------------------------------------------
// Global Variables
//-------------------------------------------------------------------------------------------------				
int  	debug=0;                     								// debug display messages enabled
bool 	quiet=false;													
bool    useflash=true;   											// Default upload bitstream to FPGA	
bool    usepsram=false;												// upload to PSRAM if true
int     sequence=0;  
bool    testmode=false;												// send test packets instead of data

uint8_t dumpbuffer[DUMP_LENGTH];									// Reading Flash/PSRAM buffer

#ifndef WIN32
struct timeval t1, t2;
#endif

FPGACommandType command = TYPE_START_DATA;

TX_UNION txData;

//-------------------------------------------------------------------------------------------------
// Main Entry 
//-------------------------------------------------------------------------------------------------
int main(int argc, char **argv)
{
	char     hexfilename[80] = "default.hex"; 						// FPGA Hex filename

	HANDLE   port;													// Serial Port handler
	int      baudrate = DEFAULT_BAUDRATE; 					   		// Default value
	char     comport[80] = DEFAULT_COMPORT;							// comport, default to com7

	bool	 sendKissCmd = false;									// send the KISS command

	if (argc < 2) usage_exit();

	//---------------------------------------------------------------------------------------------
	// Processing Command line argument(s) 
	//---------------------------------------------------------------------------------------------
	for (int i = 1; i < argc; i++) {
		if (argv[i][0] == '-') {

			switch (argv[i][1]) {

			case 'd':
				debug = debug | (int)strtol(argv[++i], NULL, 16);	// debug in hex!
				break;

			case 'c':
#ifdef WIN32
				strcpy(comport, "\\\\.\\COM");						// Required for COMPORt
				strcat(comport, argv[++i]);
#else
				strcpy(comport, argv[++i]);
#endif
				break;

			case 'f':
				strcpy(hexfilename, argv[++i]);
				break;

			case 'b':
				baudrate = (int)(atoi(argv[++i]));
				break;

			case 'k':
				sendKissCmd = true;
				break;

			case 't':
				testmode = true;
				break;
			}
		}

	}
     
    qprintf("\n**************************************************\n");
	qprintf(  "***        Efinix SPI FPGA Hex loader          ***\n");
    qprintf(  "***          Ver %d.%d (c)2026 ADRCS             ***\n", MAJOR_VERSION,MINOR_VERSION);
	qprintf(  "***     Rewritten for AMNC use by VE6VH        ***\n");
	qprintf(  "**************************************************\n");

	if (testmode)
		qprintf("Test mode selected....\n\n");

	qprintf("\nComport            : %s %d,N,8,1\n",comport,baudrate);
	
	//---------------------------------------------------------------------------------------------
	// Open Comport if the users specified the -com argument
	//---------------------------------------------------------------------------------------------
	if ((port=open_comport(comport,baudrate,'N',8,1,0))==INVALID_HANDLE_VALUE) {
		fprintf(stderr, "\nFailed to open comport %s\n",comport);
		return 1;
	}
	flushcom(port);

	//---------------------------------------------------------------------------------------------
	// Send the KISS command to enter loader
	//---------------------------------------------------------------------------------------------
	if (sendKissCmd) {
		write_comport(port, KISS_FEND, 0);
		write_comport(port, KISS_CMD,  0);
		write_comport(port, KISS_FPGA, 0);
		write_comport(port, KISS_FEND, 100);		// 100 ms delay after transmission
	}

	//---------------------------------------------------------------------------------------------
	// Upload the FPGA bitstream (that is all it does...)
	//---------------------------------------------------------------------------------------------
	upload_bitstream(port,hexfilename);						// Default upload FPGA Hex file to node071

	close_comport(port);
	
	qprintf("\nDone.\n");
    return 0; 														// change later to return error
}

//-------------------------------------------------------------------------------------------------
// Open FPGA Hex file and transmit to node071 in frames
//-------------------------------------------------------------------------------------------------	
void upload_bitstream(HANDLE port,char * hexfilename)
{
	FILE     *fp=NULL;                      						// FilePointer	
	char     line[MAX_LINE]="";	
	int      bc=0;													// Byte count, after 4 bytes send frame
		
	uint16_t status=0;
	int 	 timeout=0;
	int 	 framecount=0;											// Count number of frames, used for flash prog
	double	 addpercent=0.0;										// Each Frame adds addpercent %
	double	 progress=0.0;
	long	 st_size;
	long	 bytesent = 0;
	uint32_t flashAddr=0;											// address to write to in flash

	//---------------------------------------------------------------------------------------------
	// Open FPGA Hex file and transmit to node071 in frames
	//---------------------------------------------------------------------------------------------	
	if((fp=fopen(hexfilename,"rt"))!=NULL) {
		fprintf(stderr,"Reading Hex file   : %s\n",hexfilename);
		fprintf(stderr,"Upload to          : %s\n",useflash?"FPGA Flash":usepsram?"PSRAM":"FPGA RAM");	

		fseek(fp, 0L, SEEK_END);
		st_size = ftell(fp);
		fseek(fp, 0L, SEEK_SET);
		
		fprintf(stderr,"File size is       : %lld bytes\n\n",(long long)st_size);
		addpercent=((double)(DATA_LENGTH*100))/(((double)st_size)/3.0);

		// first time around, send start, else send data
		txData.txframe.Sync=SYNC_CHAR;
		txData.txframe.type= TYPE_START_FLASH;
		timeout=1000;

		while(fgets(line, MAX_LINE, fp)) {							// 2 hex characters per line
			sscanf(line,"%02hhx",&txData.txframe.data[bc]);
			bytesent++;
			bc=(bc+1)%DATA_LENGTH;
			if (bc==0) {
				if (testmode) {
					txData.txframe.type = TYPE_TEST_PACKET;
					txData.txframe.data[0] = (framecount >> 8) & 0xff;
					txData.txframe.data[1] = framecount & 0xff;
					for (int x = 2; x< DATA_LENGTH; x++)
						txData.txframe.data[x] = (x - 1) & 0xff;
				}
				txData.txframe.lengthHi = (uint8_t)((DATA_LENGTH >> 8) & 0xFF);
				txData.txframe.lengthLo = (uint8_t)(DATA_LENGTH  & 0xFF);

				status=write_frame(port,&txData, flashAddr, DATA_LENGTH,0,timeout);
				if (status==STATUS_NACK) goto giveup;				// BARFF...
				sequence=(sequence+1)&0x3;
				
				txData.txframe.type = TYPE_FLASH_DATA;
				framecount++;

				flashAddr += DATA_LENGTH;

				progress+=addpercent;
				printf("Uploading(%d,%d) %3.1lf%%\r",(status>>9)&1,(status>>10)&1,progress);				
			}	
#if WIN32		
			if (_kbhit()) {
				if (_getch()==0x1B) {
					printf("\nESC pressed....programming aborted\n");
					goto giveup;				
				}
			}
#else
 			if (kbhit()) {
				if (getch()==0x1B) {
					printf("\nESC pressed....programming aborted\n");
					goto giveup;				
				}
			}	   
#endif
		}
		
		// EOF reached
		if (bc) {										// Remaining bytes in a frame and not test mode
			for (int j = bc; j < DATA_LENGTH; j++)
				txData.txframe.data[j] = 0;

			txData.txframe.lengthHi = (uint8_t)((bc >> 8) & 0xFF);
			txData.txframe.lengthLo = (uint8_t)(bc & 0xFF);

			if (write_frame(port, &txData, flashAddr, DATA_LENGTH, 0, timeout) == STATUS_NACK)
				goto giveup;				// BARFF...
			sequence = (sequence + 1) & 0x3;

			framecount++;
		}
			
		fprintf(stderr, "%ld data bytes sent.\n", bytesent);

		txData.txframe.type=TYPE_END_PROGRAMMING;
		txData.txframe.lengthHi = 0;
		txData.txframe.lengthLo = 0;
		if (write_frame(port, &txData, flashAddr, 0, 0, timeout) == STATUS_NACK)
			goto giveup;
	
	} else {
        printf("\nFailed to open Hex file %s\n",hexfilename);
		return;
    }	
giveup:	
	fclose(fp);	
}

//-------------------------------------------------------------------------------------------------
// Transmit frame
// return STATUS_NACK in case of TIMEOUT/too many retries
// For BUSY bit (Flash Programming) we issue "read busy bit" command until BUSY bit is cleared.
//-------------------------------------------------------------------------------------------------
uint16_t write_frame(HANDLE port, TX_UNION *txData, uint32_t flashaddr, int txlength, int chardelay, int ms_timeout)
{	
	int retry=0;
	uint16_t status=0;
	uint8_t crc;

	crc = 0x55;

	txData->txframe.addrHi = (uint8_t)((flashaddr >> 16) & 0xFF);
	txData->txframe.addrMid = (uint8_t)((flashaddr >> 8) & 0xFF);
	txData->txframe.addrLo = (uint8_t)(flashaddr & 0xFF);
	
	for (int j= CRC_START;j< CRC_START+CRC_SIZE;j++)
		crc = updatecrc8(txData->bytes[j], crc);	

	txData->txframe.crc = crc;

	write_comport_array(port, (const unsigned char *)txData->bytes,sizeof(TX_FRAME));
	
	if (debug) {
		printf("Frame(%d%d):",(status>>9)&1,(status>>10)&1);
		for (int j=0;j<txlength;j++) 
			printf("%02x ",(uint8_t)txData->txframe.data[j]);
		printf("\n");		
	}
	
#if WIN32    
	clock_t start_time = clock();											// Start Time-out	
	while (true) {
		status=receive_frame(port);									// Wait for ACK/NACK frame
		switch (status&0x30) {
			case STATUS_WAIT :
				if (clock() > start_time + ms_timeout) {			// 1000 ms
					printf(" *** Receiver Sync Time-Out ***");
					return STATUS_NACK;
				}
				break;
			case STATUS_NACK :	
				if (retry<MAX_TX_RETRY) {
					printf("Send again\n");
					write_comport_array(port, (const unsigned char *)&txData->bytes, sizeof(TX_FRAME)); 	// Send again!
					retry++;
				} else {
					printf(" *** Too many retries ***");
					return STATUS_NACK;
				}
				break;	
			case STATUS_ACK	: 										// Ack received
				return status;
		}		
	}
#else    
	// Start Time-out
	gettimeofday(&t1, NULL);
	while (true) {
		status=receive_frame(port);									// Wait for ACK/NACK frame
		switch (status&0x30) {
			case STATUS_WAIT :
				gettimeofday(&t2, NULL);
				double elapsed = (t2.tv_sec - t1.tv_sec) * 1000.0;
				if((int)elapsed > ms_timeout)	{
					printf(" *** Receiver Sync Time-Out ***");
					return STATUS_NACK;
				}
				break;
			case STATUS_NACK :	
				if (retry<MAX_TX_RETRY) {
					printf("Send again\n");
					write_comport_array(port, (const unsigned char *)&txData->bytes, sizeof(TX_FRAME)); 	// Send again!
					retry++;
				} else {
					printf(" *** Too many retries ***");
					return STATUS_NACK;
				}
				break;	
			case STATUS_ACK	: 										// Ack received
				return status;
		}    
	}		
#endif
}

//-------------------------------------------------------------------------------------------------
// Receive frame from node071 and return status word unless dump command
//-------------------------------------------------------------------------------------------------
uint16_t receive_frame(HANDLE port)
{
	unsigned char byte;
	static uint8_t crc8=0x55;
	static int datalength=0;
	
	enum RXFSM_TYPE { FSM_RXSYNC, FSM_RXTYPE, FSM_RXSTATUS, FSM_RXDUMP, FSM_RXCRC };
    static enum RXFSM_TYPE fsm = FSM_RXSYNC;  
	
	static uint16_t status=0;
	
	if (read_comport(port,&byte)==0) return STATUS_WAIT;			// Char pending?

	switch (fsm) {
		case FSM_RXSYNC:
			if (byte==SYNC_CHAR) {
				crc8=0x55;
				fsm=FSM_RXTYPE;
			}
			break;
			
		case FSM_RXTYPE: 
			status=byte;											// LS status+Type
			crc8=updatecrc8(byte,crc8);
			if ((status&STATUS_DUMP_FLASH) || (status&STATUS_DUMP_PSRAM)) {
				datalength=0;
				fsm=FSM_RXDUMP;
			} else fsm=FSM_RXSTATUS;								// Read second status byte and exit
			break;
			
		case FSM_RXDUMP :											// Read 256 bytes	
			crc8=updatecrc8(byte,crc8);
			dumpbuffer[datalength++]=byte;
			if (datalength==DUMP_LENGTH) fsm=FSM_RXCRC;
			break;
			
		case FSM_RXSTATUS: 
			status|=(((uint16_t)byte)<<8);							// MS status
			crc8=updatecrc8(byte,crc8);
			fsm=FSM_RXCRC;
			break;		
			
		case FSM_RXCRC:
			fsm=FSM_RXSYNC;		
			if (crc8==byte) return status;
			else return STATUS_NACK;								
	}

	return STATUS_WAIT;
}

char * status2str(uint8_t status)									
{
	static char ret[MAX_WORD]="";
	
	strcpy(ret,"");
		
	if (status&CDONE_POS) strlcat(ret,"CDONE=1 ",MAX_WORD); else strlcat(ret,"cdone=0 ",MAX_WORD);	
	if (status&NSTATUS_POS) strlcat(ret,"NSTATUS=1 ",MAX_WORD); else strlcat(ret,"nstatus=0 ",MAX_WORD);	
	
	if ((status&CDONE_POS)==0 && (status&NSTATUS_POS)==0) strlcat(ret," >> Failed to Configure <<",MAX_WORD);
	if ((status&CDONE_POS)==0 && (status&NSTATUS_POS)) strlcat(ret," >> Ready for Programming... <<",MAX_WORD);
	if ((status&CDONE_POS) && (status&NSTATUS_POS)==0) strlcat(ret," >> Failure <<",MAX_WORD);
	if ((status&CDONE_POS) && (status&NSTATUS_POS)) strlcat(ret," >> FPGA in User Mode <<",MAX_WORD);
	
	return ret;
}



//-------------------------------------------------------------------------------------------------
// Update CRC8
//-------------------------------------------------------------------------------------------------
uint8_t updatecrc8(uint8_t data, uint8_t oldcrc) 
{
	uint8_t crc = oldcrc;

	crc ^= data;
	for (int j = 0; j < 8; j++) {
		if ((crc & 0x80) != 0) 
			crc = (uint8_t)((crc << 1) ^ 0x07); // standard 
		else 
			crc <<= 1;
	}
	return crc;
}


#ifndef HAVE_STRLCAT
//-------------------------------------------------------------------------------------------------
// strlcat CRC8 - Safely concatenate two strings, copied from 
// https://stackoverflow.com/users/2193455/kangear
//-------------------------------------------------------------------------------------------------
size_t strlcat(char *dst,const char *src, size_t size) 
{
  size_t    srclen;         										// Length of source string 
  size_t    dstlen;         										// Length of destination string

  dstlen = strlen(dst);
  size   -= dstlen + 1;

  if (!size) return (dstlen);        								// No room, return immediately...

  srclen = strlen(src);
  if (srclen > size) srclen = size;

  memcpy(dst + dstlen, src, srclen);
  dst[dstlen + srclen] = '\0';

  return (dstlen + srclen);
}
#endif


void usage_exit(void)
{
    printf("\n**************************************************\n");
	printf(  "***        Efinix SPI FPGA Hex loader          ***\n");
    printf(  "***          Ver %d.%d (c)2025 HT-LAB            ***\n", MAJOR_VERSION,MINOR_VERSION);
	printf(  "***      Modified for AMNC use by VE6VH         ***\n");
	printf(  "**************************************************\n");
    printf("\nUsage              : FPGAFlash <options> fpgafile.hex\n");
    printf("\nOptions:\n");
    printf("-q                : quiet, must be specified first in the options list\n");  
    printf("-c portnumber     : Comport, 1.. default to \"%s\"\n",DEFAULT_COMPORT);
    printf("-b int            : Baudrate, default is %d\n",DEFAULT_BAUDRATE);
	printf("-f                : Write hex file to FLASH memory\n");
	printf("-k                : Issue KISS command to enter loader\n");
	printf("-t                : Send test packets instead of data\n");

    printf("\n                     : press ESC to quit\n");
    exit(1);
}
