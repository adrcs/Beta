################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
src/EfinixLoader.c \
src/comlib.c \
src/conio.c \
src/errno.c 

C_DEPS += \
src/EfinixLoader.d \
src/comlib.d \
src/conio.d \
src/errno.d 

OBJS += \
src/EfinixLoader.o \
src/comlib.o \
src/conio.o \
src/errno.o 

# Each subdirectory must supply rules for building sources it contributes
src/%.o: src/%.c src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross GCC Compiler'
	arm-linux-gnueabihf-gcc -I"./Include" -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-src

clean-src:
	-$(RM) ./src/EfinixLoader.d ./src/EfinixLoader.o ./src/comlib.d ./src/comlib.o ./src/conio.d ./src/conio.o ./src/errno.d ./src/errno.o

.PHONY: clean-src

