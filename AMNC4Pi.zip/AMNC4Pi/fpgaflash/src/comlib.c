//---------------------------------------------------------------------------
// ComLib
//                                             
//    Copyright (C) 2008-2020 HT-LAB                                           
//
//---------------------------------------------------------------------------
//  Revision History:                                                        
//                                                                           
//  Date		Revision	Changes 
//	02/05/09	0.1                            
//---------------------------------------------------------------------------
#include <comlib.h>
#include <unistd.h>
#include <fcntl.h>
#include <errno.h>

#define STATUS_CHECK_TIMEOUT      5000   				// Milliseconds

/* tcflush() and TCFLSH use these */
#define	TCIFLUSH	0
#define	TCOFLUSH	1
#define	TCIOFLUSH	2

#define TERMIOS_TIMEOUT_MS 500
#define TERMIOS_TIMEOUT ((TERMIOS_TIMEOUT_MS)/100)

extern int debug;										// Set to 1 to enable debug messages

int fd;													// file descriptor for port
struct termios oldtio;									// original terminal settings
struct termios newtio;									// new settings

char *geterrno(int errnum);

int tohex(int n) 
{
	if (n<10) return (n+48); 
	     else return (n-10+65);
}

//---------------------------------------------------------------------------
// Linux Functions
//---------------------------------------------------------------------------
void flushcom(HANDLE fd)
{
	tcflush(fd, TCIFLUSH);
}


void close_comport(HANDLE fd)
{
	close(fd);
}

// serial setup: cloned from STM32flash
int serial_setup(int fd, uint32_t baud, uint8_t bits, char parity, uint8_t stopbit)
{
	speed_t	port_baud;
	tcflag_t port_bits;
	tcflag_t port_parity;
	tcflag_t port_stop;
	struct termios settings;

	switch (baud) {
		case 9600:    port_baud = B9600; break;
		case 19200:   port_baud = B19200; break;
		case 38400:   port_baud = B38400; break;
		case 57600:   port_baud = B57600; break;
		case 115200:  port_baud = B115200; break;
		case 230400:  port_baud = B230400; break;
		case 460800:  port_baud = B460800; break;
		case 921600:  port_baud = B921600; break;
		case 500000:  port_baud = B500000; break;
		case 576000:  port_baud = B576000; break;
		case 1000000: port_baud = B1000000; break;
		case 1152000: port_baud = B1152000; break;
		case 1500000: port_baud = B1500000; break;
		case 2000000: port_baud = B2000000; break;
		case 2500000: port_baud = B2500000; break;
		case 3000000: port_baud = B3000000; break;
		case 3500000: port_baud = B3500000; break;
		case 4000000: port_baud = B4000000; break;

		default:
			return INVALID_HANDLE_VALUE;
	}

	switch (bits) {
		case 5: port_bits = CS5; break;
		case 6: port_bits = CS6; break;
		case 7: port_bits = CS7; break;
		case 8: port_bits = CS8; break;

		default:
			return INVALID_HANDLE_VALUE;
	}

	switch (parity) {
		case 'N': port_parity = 0; break;
		case 'E': port_parity = PARENB; break;
		case 'O':  port_parity = PARENB | PARODD; break;

		default:
			return INVALID_HANDLE_VALUE;
	}

	switch (stopbit) {
		case 1: port_stop = 0;	   	break;
		case 2: port_stop = CSTOPB; break;

		default:
			return INVALID_HANDLE_VALUE;
	}

	/* reset the settings */
	cfmakeraw(&newtio);
	newtio.c_cflag &= ~(CSIZE | CRTSCTS);
	newtio.c_cflag &= ~(CSIZE | CRTSCTS);
	newtio.c_cflag &= ~(PARENB | PARODD);
	newtio.c_cflag &= ~CSTOPB;
	newtio.c_iflag &= ~(IXON | IXOFF | IXANY | IGNPAR);
	newtio.c_lflag &= ~(ECHOK | ECHOCTL | ECHOKE);
	newtio.c_oflag &= ~(OPOST | ONLCR);

	/* setup the new settings */
	if (cfsetispeed(&newtio, port_baud) ||
	    cfsetospeed(&newtio, port_baud)) {
		fprintf(stderr, "Failed to specify baud rate\n");
		return INVALID_HANDLE_VALUE;
	}

	newtio.c_cflag |=
		port_parity	|
		port_bits	|
		port_stop	|
		CLOCAL		|
		CREAD;
	if ( port_parity != 0 )
		newtio.c_iflag |= INPCK;

	newtio.c_cc[VMIN] = 0;
	newtio.c_cc[VTIME] = TERMIOS_TIMEOUT;	/* in units of 0.1 s */

	/* set the settings */
	flushcom(fd);
	if (tcsetattr(fd, TCSANOW, &newtio) != 0) {
		fprintf(stderr, "Error: Failed to apply settings\n");
		return INVALID_HANDLE_VALUE;
	}

	/* confirm they were set */
	tcgetattr(fd, &settings);

	if (cfgetispeed(&settings) != port_baud ||
	    cfgetospeed(&settings) != port_baud) {
		fprintf(stderr, "Failed to set baud rate\n");
		return INVALID_HANDLE_VALUE;
	}
	if (settings.c_iflag != newtio.c_iflag ||
	    settings.c_oflag != newtio.c_oflag ||
	    settings.c_cflag != newtio.c_cflag ||
	    settings.c_lflag != newtio.c_lflag) {
		fprintf(stderr, "Failed to set terminal flags\n");
		return INVALID_HANDLE_VALUE;
	}

	return 0;
}

// open the port
HANDLE open_comport(char *device,uint32_t baud, char parity,int databits,int stopbits,int options)
{
	fd = open(device, O_RDWR | O_NOCTTY | O_NDELAY);
	if (fd < 0) {
		return INVALID_HANDLE_VALUE;
	}

	if(lockf(fd,F_TLOCK,0) != 0)
	{
		fprintf(stderr, "Error: %s is already open\n", device);
		return INVALID_HANDLE_VALUE;
	}
	fcntl(fd, F_SETFL, 0);

	tcgetattr(fd, &oldtio);
	tcgetattr(fd, &newtio);

	if(serial_setup(fd, baud, databits, parity, stopbits) == INVALID_HANDLE_VALUE)	{
		fprintf(stderr, "Serial word formatting error\n");
		return INVALID_HANDLE_VALUE;
	}

	tcgetattr(fd, &oldtio);
	return fd;
}


//---------------------------------------------------------------------------
// Write single char to comport, txdelay in ms
// return chars written
// uses linux write: ssize_t write (fd, buf, count)
//---------------------------------------------------------------------------
int write_comport(HANDLE port, unsigned char c, int txdelay)
{
	ssize_t bytesWritten = 0;
	
    if ((bytesWritten=write(port,&c,1)) > 0) {
		if (bytesWritten && (DEBUG_UART)) {
			printf("%02X",c);
		}
	} else {
		printf("WriteFile failed error=%s\n",geterrno(errno));
	}
	if(txdelay)	{
		useconds_t usec = (useconds_t)txdelay*1000;
		usleep(usec);							// Delay in ms after TX
	}
	return (int)bytesWritten;
}

//---------------------------------------------------------------------------
// Write array to comport
// return chars written  
//---------------------------------------------------------------------------
int write_comport_array(HANDLE port, const unsigned char *buffer, int len)
{
	ssize_t bytesWritten = 0;

	if (len==0) {
		printf("\nTrying to transmit zero bytes??");
		return 0;
	}

    if ((bytesWritten=write(port,buffer,len)) > 0) {
		if ((bytesWritten==(ssize_t)len) && (DEBUG_UART)) {
			for (int n=0;n<len;n++) printf("%02X",buffer[n]);
		}			
	} else {
	   printf(" >>> WriteFile failed, %d bytes written, error=%s\n",bytesWritten,geterrno(errno));
	}

	return (int)bytesWritten;
}

//---------------------------------------------------------------------------
// get character from comport
// return 0 if timeout, !=0 if OK  
//---------------------------------------------------------------------------
int read_comport(HANDLE port, unsigned char *c)
{
	ssize_t bytesRead=0;
	unsigned char rxChar=0;

	if ((bytesRead = read(port, &rxChar, 1)) != 0) {
		if (bytesRead) {
		    if (DEBUG_UART)
			printf("{rx:%02x}",rxChar);
	            *c=rxChar; // clean up
		}
	}		
	return bytesRead;
}

//---------------------------------------------------------------------------
// fill array from comport
// return 0 if timeout, rx buffer length if OK  
//---------------------------------------------------------------------------
int read_comport_array(HANDLE port, unsigned char *buffer, int buflen)
{
	ssize_t bytesRead=0;
	int n=0;

	do {
		if ((bytesRead = read(port, &buffer[n++], 1)) != 0) {
			if (bytesRead) {
				if (DEBUG_UART) printf("%02x",buffer[n-1]);
			}		
		} else {
	   		printf("ReadFile failed with error=%s\n",geterrno(errno));
		}
	} while (bytesRead!=0 && n<buflen);

   	return n-1;
}

