/*
 * frametypes.h
 *
 *  Created on: Apr 8, 2025
 *      Author: hans6
 */

#ifndef INC_FRAMETYPES_H_
#define INC_FRAMETYPES_H_

#define SYNC_CHAR					0x7E
#define STUFF_CHAR  				0x3E

#define DATA_LENGTH					256								// Data received from Efinixloader, do not lower than 16bytes and use power(2)

#define STATUS_LENGTH				1								// Send back to Efinixloader
#define STATUS_FRAME_LENGTH         (1+1+STATUS_LENGTH+1)			// Do not change, hardcoded length in receive_frame

#define CMD_DATA_LENGTH				1								// Optional Byte

#define DUMP_LENGTH					256								// FLASH/PSRAM Dump data length
#define DUMP_FRAME_LENGTH           (1+1+DUMP_LENGTH+1)				// SYNC-STATUS-DUMP_DATA-CRC

//--------------------------------------------------------------------------------------------------
// Flash defines
//--------------------------------------------------------------------------------------------------
#define T20_FLASH_SIZE              (1024 * 1024 * 2)        		// 2Mbyte
#define T20_FLASH_PAGE_SIZE         256								// Assume compatible with Winbond W25Qxx 256 Page program
#define T20_FLASH_SECTOR_SIZE       4096							// Assume compatible with Winbond W25Qxx minimum erase size
#define MAX_BUSY_RETRY				5								// Max 5ms for 1 page write, if busy=1 send NACK


#if T20_FLASH_PAGE_SIZE != DUMP_LENGTH
	#error "T20_FLASH_PAGE_SIZE and DUMP_LENGTH must be equal!"
#endif


//--------------------------------------------------------------------------------------------------
// Flash defines
//--------------------------------------------------------------------------------------------------
#define T20_FLASH_SIZE              (1024 * 1024 * 2)        		// 2Mbyte
#define T20_FLASH_PAGE_SIZE         256								// Assume compatible with Winbond W25Qxx 256 Page program
#define T20_FLASH_SECTOR_SIZE       4096							// Assume compatible with Winbond W25Qxx minimum erase size
#define MAX_BUSY_RETRY				5								// Max 5ms for 1 page write, if busy=1 send NACK


//--------------------------------------------------------------------------------------------------
// Command Field Types first 6 bits
//--------------------------------------------------------------------------------------------------
typedef enum {
	TYPE_START_DATA = 0,			// 00: upload FPGA
	TYPE_START_FLASH,			// 01: upload flash memory
	TYPE_START_RAM,				// 02: ram data upload
	TYPE_FPGA_DATA,				// 03: flash data upload
	TYPE_FLASH_DATA,			// 04: flash data
	TYPE_RAM_DATA,				// 05: ram data
	TYPE_TEST_PACKET,			// 07: test packet
	TYPE_END_PROGRAMMING		// 06: end of programming
} FPGACommandType;

#define TYPE_ENABLE_UART			0x20							// Connect STM32 UART_TX to GPIO40
#define TYPE_DISABLE_UART			0x21							// Change STM32 UART_TX to input so that GPIO40 is free
#define TYPE_SET_BAUDRATE			0x22							// Set UART Baudrate between STM32 to FPGA

#define	TYPE_DEBUG_STATUS 			0x30
#define TYPE_DUMP_FLASH             0x35							// Dump 256 bytes from FLASH
#define TYPE_DUMP_PSRAM             0x36							// Dump 256 bytes from PSRAM
//#define TYPE_SET_BAUDRATE			0x80							// TBC

#define TYPE_PORTA                  0x10							// 0001000
#define TYPE_PORTB                  0x20							// 0001000
#define TYPE_PORTC                  0x30							// 0001000




//--------------------------------------------------------------------------------------------------
// TXFRAME type wait bit 0
//--------------------------------------------------------------------------------------------------
#define STATUS_BUSY					0x01							// xxxx-xxx1

//--------------------------------------------------------------------------------------------------
// TXFRAME dump bits bit 2:1
//--------------------------------------------------------------------------------------------------
#define STATUS_DUMP_FLASH			0x02							// xxxx-x01x
#define STATUS_DUMP_PSRAM			0x04							// xxxx-x10x

//--------------------------------------------------------------------------------------------------
// TXFRAME type bit 5:4 send back to EfinixLoader
//--------------------------------------------------------------------------------------------------
#define STATUS_NACK					0x10							// xx01-xxxx
#define STATUS_ACK					0x20							// xx10-xxxx
#define STATUS_WAIT					0x30							// xx11-xxxx


//-------------------------------------------------------------------------------------------------
// Status bit positions in second status byte
//-------------------------------------------------------------------------------------------------
#define NSTATUS_POS					0x01
#define CDONE_POS					0x02
#define CDI3_POS					0x04
#define SS_N_POS                    0x08

#endif /* INC_FRAMETYPES_H_ */
