/*---------------------------------------------------------------------------
        Project:          FPGAFlash

        File Name:        conio.h

        Author:           Martin, VE6VH

        Creation Date:    May 19, 2026

        Description:      Header file for console I/O

                          This program is free software: you can redistribute it and/or modify
                          it under the terms of the GNU General Public License as published by
                          the Free Software Foundation, either version 2 of the License, or
                          (at your option) any later version, provided this copyright notice
                          is included.

                          Copyright (c) 2024-25 Alberta Digital Radio Communications Society

---------------------------------------------------------------------------*/

#ifndef CONIO_H_
#define CONIO_H_

void set_conio_terminal_mode(void);			// set terminal mode
int kbhit(void);							// is kb hit?
int getch(void);							// get a char

#endif /* CONIO_H_ */
