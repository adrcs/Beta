//---------------------------------------------------------------------------
// ComLib
//                                             
//    Copyright (C) 2008-2009 HT-LAB                                           
//
//---------------------------------------------------------------------------
//  Revision History:                                                        
//                                                                           
//  Date		Revision	Changes 
//	02/05/09	0.1                              
//---------------------------------------------------------------------------
#pragma once

#include <stdio.h>	
#include <stdint.h>
#include <termios.h>

#define DEBUG_ERROR		(debug&0x0001)								// Print Error Messages, like invalid peripheral access							//
#define DEBUG_UART      (debug&0x0002)
#define VERBOSE_DEBUG	(debug&0x8000)

// Baud rate translations
#define  B9600		0000015
#define  B19200		0000016
#define  B38400		0000017
#define  B57600    0010001
#define  B115200   0010002
#define  B230400   0010003
#define  B460800   0010004
#define  B500000   0010005
#define  B576000   0010006
#define  B921600   0010007
#define  B1000000  0010010
#define  B1152000  0010011
#define  B1500000  0010012
#define  B2000000  0010013
#define  B2500000  0010014
#define  B3000000  0010015
#define  B3500000  0010016
#define  B4000000  0010017
#define __MAX_BAUD B4000000

// sizes, etc
#define CSIZE	0000060
#define   CS5	0000000
#define   CS6	0000020
#define   CS7	0000040
#define   CS8	0000060
#define PARENB	0000400
#define PARODD	0001000
#define CSTOPB	0000100

typedef int	HANDLE;
#define INVALID_HANDLE_VALUE	-1				// error on open, etc
	
void flushcom(HANDLE port);
void close_comport(HANDLE port);
HANDLE open_comport(char *devicename,uint32_t baud,char parity,int databits,int stopbits,int options);
int write_comport(HANDLE port, unsigned char c, int txdelay);
int read_comport(HANDLE port, unsigned char *c);
int write_comport_array(HANDLE port, const unsigned char *buffer, int len);
uint8_t gencrc(uint8_t *data, size_t len);
