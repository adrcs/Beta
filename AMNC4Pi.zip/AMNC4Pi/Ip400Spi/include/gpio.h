/*---------------------------------------------------------------------------
        Project:          Ip400Spi

        File Name:        gpio.h

        Author:           martin A

        Creation Date:    Nov. 4, 2025

        Description:      definitions for gpio routines

                          This program is free software: you can redistribute it and/or modify
                          it under the terms of the GNU General Public License as published by
                          the Free Software Foundation, either version 2 of the License, or
                          (at your option) any later version, provided this copyright notice
                          is included.

                          Copyright (c) 2024-25 Alberta Digital Radio Communications Society

---------------------------------------------------------------------------*/

#ifndef INCLUDE_GPIO_H_
#define INCLUDE_GPIO_H_

typedef enum gpio_level_e	{
		GPIO_LEVEL_LOW=0,				// drive GPIO Low
		GPIO_LEVEL_HIGH					// drive GPIO High
} GPIOLevel;

typedef enum gpio_status_e	{
		GPIO_ERR=0,						// error
		GPIO_OK							//  operation completed
} GPIOStatus;

// links in
GPIOStatus gpio_reset(int gpioNum);

#endif /* INCLUDE_GPIO_H_ */
