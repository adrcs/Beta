/*---------------------------------------------------------------------------
        Project:          Ip400Spi

        File Name:        spidefs.h

        Author:           root

        Creation Date:    Mar. 6, 2025

        Description:      Definitions for the SPI interface

                          This program is free software: you can redistribute it and/or modify
                          it under the terms of the GNU General Public License as published by
                          the Free Software Foundation, either version 2 of the License, or
                          (at your option) any later version, provided this copyright notice
                          is included.

                          Copyright (c) 2024-25 Alberta Digital Radio Communications Society

---------------------------------------------------------------------------*/
#ifndef SPIDEFSH
#define SPIDEFSH

#include <unistd.h>
#include <sys/ioctl.h>
#include <linux/spi/spidev.h>
#include <stdint.h>
#include <fcntl.h>
#include <stdio.h>
#include <errno.h>
#include <frame.h>
#include <stdlib.h>

#include "types.h"
#include "spi.h"

// typedefs
typedef   uint8_t				SPI_WORD;     // single byte
typedef   uint16_t 				SPI_DWORD;    // double byte
typedef   uint32_t				SPI_QWORD;	  // quad word

// SPI defines
enum {
	SPI_0_0=0,			// SPI device 0 CS 0
	SPI_0_1,			// SPI device 0 CS 1
	SPI_1_0,			// SPI device 1 CS 0
	SPI_1_1,			// SPI device 1 CS 1
	SPI_1_2,			// SPI device 1 CS 2
	N_SPI				// number of SPI devices
};

#define   SPI_0_DEV_0       "/dev/spidev0.0"
#define   SPI_0_DEV_1       "/dev/spidev0.1"
#define   SPI_1_DEV_0       "/dev/spidev1.0"
#define   SPI_1_DEV_1       "/dev/spidev1.1"
#define   SPI_1_DEV_2       "/dev/spidev1.2"
#define   SPI_SPEED         500000
#define   SPI_SLOW_SPEED    100000
#define	  SPI_NBITS	    	8				// All Spi's are 8 bits
#define   SPI_RESET_COUNT   10				// number of times to hold spi reset

// status returns from updates
#define   SPI_REG_SUCCESS   0               // successful completion
#define   SPI_REG_INVALID   -1              // invalid register called
#define	  PAYLOAD_MAX		1053			// max frame payload

// loopback and test modes
typedef enum	{
	NO_LOOP=0,			// no loopback
	LOOP_SPI,			// loopback at the SPI level
	LOOP_NODE			// loopback at the node level
} loopbackModes;


// SPI struct
typedef struct spi_config_t	{
	uint8_t		 	mode;				// mode
	uint8_t		 	bitsPerWord;		// bits/word
	uint32_t	 	speed;				// speed
	int				fd;					// file descriptor
	uint8_t			debug;				// debug
} SPI_CONFIG;

// UDP Data frame
#define	MAX_UDP_BUFFER		1500			// max buffer size
#define	UDP_BUF_SIZE		(MAX_UDP_BUFFER-sizeof(SPI_HEADER))
typedef union udp_frame_u	{
		struct {
			SPI_HEADER			hdr;					// header
			uint8_t				data[UDP_BUF_SIZE];		// data portion
		} spiData;
		uint8_t	rawData[MAX_UDP_BUFFER];
} UDP_FRAME;

// tx frame queued for SPI
typedef struct spi_frame_queue_t	{
	UDP_FRAME		*buffer;			// raw udp frame
	uint16_t		length;				// length
} SPI_FRAME_QUEUE;

//  SPI task
int spi_lookup(char *devName);
BOOL spiTaskInit(int spiDev);
void spiTask(loopbackModes loopback);

// SPI functions
void spi_setup(int device, uint8_t spiMode, uint8_t spibitsPerWord, int spiSpeed, uint8_t debug);
int spi_open(int device);
int spi_close(int device);
int spi_fdtransfer(int device, SPI_WORD *txdata, SPI_WORD *rxdata, int length);
int spi_hdread(int fd, uint8_t *data, uint16_t length);
int spi_hdwrite(int fd, uint8_t *data, uint16_t length);

// UDP stuff
BOOL setup_udp_socket(char *hostname, int hostport, int localport, int debug);
BOOL send_udp_packet(void *data, uint16_t length);
BOOL process_UDP_outbound(SPI_BUFFER *rxBuffer);

//
void initFrameQueues(void);
BOOL EnqueUDPFrame(UDP_FRAME *rxFrame, int length);
BOOL process_SPI_Receive(SPI_BUFFER *rxBuffer);
SPI_FRAME_QUEUE *getNextSpiFrame(void);
BOOL EnqueSPIFrame(SPI_FRAME_QUEUE *SrcFrame);

#endif

