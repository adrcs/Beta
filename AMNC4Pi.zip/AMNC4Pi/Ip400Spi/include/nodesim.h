/*---------------------------------------------------------------------------
        Project:          Ip400Spi

        File Name:        nodesim.h

        Author:           Martin A

        Creation Date:    Jan. 13, 2026

        Description:      Routines to create a framework for node spi fsm

                          This program is free software: you can redistribute it and/or modify
                          it under the terms of the GNU General Public License as published by
                          the Free Software Foundation, either version 2 of the License, or
                          (at your option) any later version, provided this copyright notice
                          is included.

                          Copyright (c) 2024-25 Alberta Digital Radio Communications Society

---------------------------------------------------------------------------*/

#ifndef INCLUDE_NODESIM_H_
#define INCLUDE_NODESIM_H_

#include "spi.h"

// simulation routines
void nodeSimInit(SPI_BUFFER *spiTxBuffer);
void nodeInterruptSim(SPI_BUFFER *spiRxBuffer, int length);
BOOL runNodeFSM(void);

void SpiFSMInit(SPI_STATS *stats, SPI_BUFFER *spiTxBuffer);
void SpiFSM(FRAME_QUEUE *spiRxQueue, FRAME_QUEUE *spiTxQueue);

void SendSPIFrame(void *spi, uint8_t *payload, int len);

#endif /* INCLUDE_NODESIM_H_ */
