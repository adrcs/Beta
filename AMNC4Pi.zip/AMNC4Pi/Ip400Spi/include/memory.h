/*---------------------------------------------------------------------------
	Project:	      IP400 Mini Node

	Module:		      memory management

	File Name:	      memory.h

	Date Created:	  Jan 4, 2026

	Author:			  MartinA

	Description:      Definitions for the memory manager

					  Copyright © 2024-25, Alberta Digital Radio Communications Society,
					  All rights reserved


	Revision History:

---------------------------------------------------------------------------*/


#ifndef IP400_INC_MEMORY_H_
#define IP400_INC_MEMORY_H_

/*	modules that allocate memory definitions	*/
typedef enum mem_alloc_e	{
	UDP=0,					// chat module
	DATAQ,					// data queueing/dequeing
	FRAME,					// frame manager
	KISS,					// KISS manager
	SPI,					// SPI handler
	SUBG,					// Sub-GHz radio
	OTHERS,					// all others
	N_MEM_ALLOCS			// number of stats
} MEM_ALLOCS;

extern int nAllocs[N_MEM_ALLOCS];

// mem allocators/deallocators
void *nodeMemAlloc(int module, size_t size);
void nodeMemFree(int module, void *mem);

void PrintAllocStats(void);


#endif /* IP400_INC_MEMORY_H_ */
