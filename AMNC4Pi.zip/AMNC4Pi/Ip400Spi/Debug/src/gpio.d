src/gpio.o: ../src/gpio.c \
 /home/martin/eclipse-workspace/Ip400Spi/include/gpio.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/logger.h

/home/martin/eclipse-workspace/Ip400Spi/include/gpio.h:

/home/martin/eclipse-workspace/Ip400Spi/include/logger.h:
