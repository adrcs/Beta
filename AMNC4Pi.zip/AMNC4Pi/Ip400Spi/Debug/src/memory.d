src/memory.o: ../src/memory.c \
 /home/martin/eclipse-workspace/Ip400Spi/include/memory.h

/home/martin/eclipse-workspace/Ip400Spi/include/memory.h:
