src/nodesim.o: ../src/nodesim.c \
 /home/martin/eclipse-workspace/Ip400Spi/include/dataq.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/types.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/spi.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/frame.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/memory.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/nodesim.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/spi.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/logger.h

/home/martin/eclipse-workspace/Ip400Spi/include/dataq.h:

/home/martin/eclipse-workspace/Ip400Spi/include/types.h:

/home/martin/eclipse-workspace/Ip400Spi/include/spi.h:

/home/martin/eclipse-workspace/Ip400Spi/include/frame.h:

/home/martin/eclipse-workspace/Ip400Spi/include/memory.h:

/home/martin/eclipse-workspace/Ip400Spi/include/nodesim.h:

/home/martin/eclipse-workspace/Ip400Spi/include/spi.h:

/home/martin/eclipse-workspace/Ip400Spi/include/logger.h:
