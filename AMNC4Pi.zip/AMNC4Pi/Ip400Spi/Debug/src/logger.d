src/logger.o: ../src/logger.c \
 /home/martin/eclipse-workspace/Ip400Spi/include/types.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/logger.h

/home/martin/eclipse-workspace/Ip400Spi/include/types.h:

/home/martin/eclipse-workspace/Ip400Spi/include/logger.h:
