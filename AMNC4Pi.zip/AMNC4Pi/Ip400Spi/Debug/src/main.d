src/main.o: ../src/main.c \
 /home/martin/eclipse-workspace/Ip400Spi/include/types.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/logger.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/spidefs.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/frame.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/types.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/spi.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/timer.h \
 /home/martin/eclipse-workspace/Ip400Spi/include/gpio.h

/home/martin/eclipse-workspace/Ip400Spi/include/types.h:

/home/martin/eclipse-workspace/Ip400Spi/include/logger.h:

/home/martin/eclipse-workspace/Ip400Spi/include/spidefs.h:

/home/martin/eclipse-workspace/Ip400Spi/include/frame.h:

/home/martin/eclipse-workspace/Ip400Spi/include/types.h:

/home/martin/eclipse-workspace/Ip400Spi/include/spi.h:

/home/martin/eclipse-workspace/Ip400Spi/include/timer.h:

/home/martin/eclipse-workspace/Ip400Spi/include/gpio.h:
