################################################################################
# Automatically-generated file. Do not edit!
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../src/dataq.c \
../src/errno.c \
../src/frame.c \
../src/gpio.c \
../src/logger.c \
../src/main.c \
../src/memory.c \
../src/nodesim.c \
../src/spi.c \
../src/spifsm.c \
../src/spitask.c \
../src/timer.c \
../src/udp.c 

C_DEPS += \
./src/dataq.d \
./src/errno.d \
./src/frame.d \
./src/gpio.d \
./src/logger.d \
./src/main.d \
./src/memory.d \
./src/nodesim.d \
./src/spi.d \
./src/spifsm.d \
./src/spitask.d \
./src/timer.d \
./src/udp.d 

OBJS += \
./src/dataq.o \
./src/errno.o \
./src/frame.o \
./src/gpio.o \
./src/logger.o \
./src/main.o \
./src/memory.o \
./src/nodesim.o \
./src/spi.o \
./src/spifsm.o \
./src/spitask.o \
./src/timer.o \
./src/udp.o 


# Each subdirectory must supply rules for building sources it contributes
src/%.o: ../src/%.c src/subdir.mk
	@echo 'Building file: $<'
	@echo 'Invoking: Cross GCC Compiler'
	arm-linux-gnueabihf-gcc -I"/home/martin/eclipse-workspace/Ip400Spi/include" -O0 -g3 -Wall -c -fmessage-length=0 -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" -o "$@" "$<"
	@echo 'Finished building: $<'
	@echo ' '


clean: clean-src

clean-src:
	-$(RM) ./src/dataq.d ./src/dataq.o ./src/errno.d ./src/errno.o ./src/frame.d ./src/frame.o ./src/gpio.d ./src/gpio.o ./src/logger.d ./src/logger.o ./src/main.d ./src/main.o ./src/memory.d ./src/memory.o ./src/nodesim.d ./src/nodesim.o ./src/spi.d ./src/spi.o ./src/spifsm.d ./src/spifsm.o ./src/spitask.d ./src/spitask.o ./src/timer.d ./src/timer.o ./src/udp.d ./src/udp.o

.PHONY: clean-src

