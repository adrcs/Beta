/*---------------------------------------------------------------------------
        Project:          Ip400Spi

        File Name:        nodesim.c

        Author:           Martin A

        Creation Date:    Jan. 13, 2026

        Description:      Simulation of node routines to use SPI code

                          This program is free software: you can redistribute it and/or modify
                          it under the terms of the GNU General Public License as published by
                          the Free Software Foundation, either version 2 of the License, or
                          (at your option) any later version, provided this copyright notice
                          is included.

                          Copyright (c) 2024-25 Alberta Digital Radio Communications Society

---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdint.h>
#include <stddef.h>
#include <malloc.h>
#include <string.h>

#include "dataq.h"
#include "spi.h"
#include "memory.h"
#include "nodesim.h"
#include "logger.h"
#include "frame.h"

// fudge a MAC address
IP400_MAC myMac = {
		.callbytes.callsign.bytes = { 0xFF, 0x1E, 0x45, 0x12 },
		.vpnBytes.vpn = { 0xFF, 0xE0 }
};

// stats
SPI_STATS	stats;
// local defn's
uint32_t  nextSeq;		// next frame sequence number

// frame queues
FRAME_QUEUE spiRxQueue;
FRAME_QUEUE spiTxQueue;			// queue for outbound

/*
 * simulation routines to include the node code
 */

SPI_BUFFER *spiTxBuffer;

// initialization
void nodeSimInit(SPI_BUFFER *spiTxBuffer)
{
	// tx (outbound) frame queue
	spiTxQueue.q_forw = &spiTxQueue;
	spiTxQueue.q_back = &spiTxQueue;

	// create the inbound frame queue
	spiRxQueue.q_forw = &spiRxQueue;
	spiRxQueue.q_back = &spiRxQueue;

	nextSeq = 0;

	SpiFSMInit(&stats, spiTxBuffer);
}

// run the FSM
BOOL runNodeFSM(void)
{
	SPI_HDR_STATUS obStatus;

	SpiFSM(&spiRxQueue, &spiTxQueue);

	obStatus.status_byte = spiTxBuffer->spiData.hdr.spiStat;
	spiFrameStatus rstat = obStatus.frameStat.status;

	// frame with status in the correct range
	if((rstat > NO_FRAME) && (rstat < N_STATUS))	{
		logger(LOG_DEBUG, "Node FSM:  SPI frame %s\n", formatHeader(spiTxBuffer));
		return TRUE;
	}

	return FALSE;

}

// completion of SPI interrupt simulation
void nodeInterruptSim(SPI_BUFFER *spiRxBuffer, int length)
{
	SPI_HDR_STATUS ibStatus;
	SPI_BUFFER *rxFrame;

	// if the receiver has a valid frame, queue it and allocate another
	ibStatus.status_byte = spiRxBuffer->spiData.hdr.spiStat;
	spiFrameStatus rstat = ibStatus.frameStat.status;

	// frame with status in the correct range
	if((rstat > NO_FRAME) && (rstat < N_STATUS))	{
		if((rxFrame=nodeMemAlloc(SPI,length)) != NULL)	{
			memcpy(rxFrame, spiRxBuffer->rawData, length);
			enqueFrame(&spiRxQueue, rxFrame, 0);
		}
	}
}

/*
 * Send a frame received on the SPI
 * NB: input frame has a different format
 * direct copy from frame.c
 */
void SendSPIFrame(void *spi, uint8_t *payload, int len)
{
	/*
	 * new frame format: *spi = <header> *payload = <src ext><dest ext><hop Table><payload>
	 */

	IP400_FRAME *ip400Frame;

	SPI_HEADER *spiHdr = (SPI_HEADER *)spi;
	SPI_BYTE_FLAGS spiFlags;

	// allocate memory for the SPI frame and buffer
	if((ip400Frame=nodeMemAlloc(FRAME,sizeof(IP400_FRAME))) == NULL)
		return;

	// step 0: extended call signs first
	spiFlags.bytedefs[1] = spiHdr->flagsLSB;
	spiFlags.bytedefs[0] = spiHdr->flagsMSB;

	if(spiFlags.bitdefs.srcExt)	{
		memcpy(&ip400Frame->srcExt, payload, N_CALL);
		payload += N_CALL;
		len -= N_CALL;
	}
	if(spiFlags.bitdefs.destExt)	{
		memcpy(&ip400Frame->destExt, payload, N_CALL);
		payload += N_CALL;
		len -= N_CALL;
	}

	// step 1: process hop table entry next
	HOPTABLE *hTable;
	SPI_HOPTABLE *spiHop = (SPI_HOPTABLE *)payload;
	if(spiFlags.bitdefs.hoptable)		{
		if((hTable=nodeMemAlloc(FRAME,sizeof(HOPTABLE))) == NULL)	{
			nodeMemFree(FRAME,ip400Frame);
			return;
		}
		for(int i=0;i<MAX_HOPS;i++)		{
			hTable->rptCalls[i].callbytes.callsign.encoded = spiHop->hopEntry->callentry.callsign.encoded;
			hTable->flags[i] = spiHop->hopEntry->flags;
		}
		payload += sizeof(SPI_HOPTABLE);
		len -= sizeof(SPI_HOPTABLE);
		ip400Frame->hopTable = hTable;
	} else {
		ip400Frame->hopTable = (void *)NULL;
		ip400Frame->flagfld.flags.hoptable = FALSE;
	}

	// Step 2: the rest is the payload
	if((ip400Frame->buf=nodeMemAlloc(FRAME,len)) == NULL)	{
		if(ip400Frame->flagfld.flags.hoptable)
			nodeMemFree(FRAME,hTable);
		nodeMemFree(FRAME,ip400Frame);
		return;
	}
	memcpy(ip400Frame->buf, payload, len);

	// Step 3: to and from callsigns
	uint8_t *srcCall;
	srcCall = myMac.callbytes.callsign.bytes;
	memcpy(ip400Frame->source.callbytes.callsign.bytes, srcCall, N_CALL);
	memcpy(ip400Frame->source.vpnBytes.vpn, spiHdr->fromIP, N_IPBYTES);
	memcpy(ip400Frame->dest.callbytes.callsign.bytes, spiHdr->toCall, N_CALL);
	memcpy(ip400Frame->dest.vpnBytes.vpn, spiHdr->toIP, N_IPBYTES);

	// step 4: header flags
	ip400Frame->flagfld.flagBytes[0] = spiFlags.bytedefs[0];
	ip400Frame->flagfld.flagBytes[1] = spiFlags.bytedefs[1];

	// these are separate
	ip400Frame->flagfld.flags.fragmentation = spiHdr->spiStat - SINGLE_FRAME;
	ip400Frame->flagfld.flags.coding = spiHdr->coding & 0xf;
	ip400Frame->flagfld.flags.payloadMSB = (len & 0x100) >> 8;

	ip400Frame->seqNum = nextSeq++;
	ip400Frame->length = len & 0xFF;

	enqueFrame(&spiTxQueue, ip400Frame, len);
	// was: QueueTxFrame(spiFrame);

}




