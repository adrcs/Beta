/*---------------------------------------------------------------------------
        Project:          Ip400Spi

        File Name:        spifsm.c

        Author:           Martin, VE6VH

        Creation Date:    Jan. 13, 2026

        Description:      This is the state machine for the node SPI handler

                          This program is free software: you can redistribute it and/or modify
                          it under the terms of the GNU General Public License as published by
                          the Free Software Foundation, either version 2 of the License, or
                          (at your option) any later version, provided this copyright notice
                          is included.

                          Copyright (c) 2024-25 Alberta Digital Radio Communications Society

---------------------------------------------------------------------------*/
#include <string.h>

#include "dataq.h"
#include "frame.h"
#include "spidefs.h"
#include "memory.h"
#include "spi.h"

SPI_BUFFER *spiRxFrame;
SPI_BUFFER *spiTxBuffer;

SPI_STATS *spi_stats;					// spi stats

/*
 * Initialization: set up the FSM constants
 */
void SpiFSMInit(SPI_STATS *stats, SPI_BUFFER *spiTx)
{
	spi_stats = stats;
	spiTxBuffer = spiTx;
}

/*
 * Run the FSM. Inputs are received frames from the SPI to be transmitted, and received IP400 frames to be
 * sent to the SPI
 */
void SpiFSM(FRAME_QUEUE *spiRxQueue, FRAME_QUEUE *spiTxQueue)
{

	static IP400_FRAME *txFrame;
	static uint16_t rxSegLen;

	/*
	 * Inbound frame from SPI. Queue for transmit
	 */

	// check for an inbound frame to send
	if((spiRxFrame = (SPI_BUFFER *)dequeFrame(spiRxQueue)) != NULL)	{
		rxSegLen =  ((uint16_t)spiRxFrame->spiData.hdr.length_hi)<<8;
		rxSegLen += ((uint16_t)spiRxFrame->spiData.hdr.length_lo);
		SendSPIFrame(&spiRxFrame->spiData.hdr, (uint8_t *)&spiRxFrame->spiData.buffer, rxSegLen);
		spi_stats->nOBIP400Frames++;
		nodeMemFree(SPI,spiRxFrame);
	}

	/*
	 * Outbound frame for SPI
	 */

	if((txFrame=dequeFrame(spiTxQueue)) == NULL)	{
		spiTxBuffer->spiData.hdr.spiStat = NO_FRAME;
	} else {

		/*
		 * reformat an IP400 frame into an SPI frame
		 */
		// step 0: common fields
		memcpy(&spiTxBuffer->spiData.hdr.fromCall, txFrame->source.callbytes.callsign.bytes, N_CALL);
		memcpy(&spiTxBuffer->spiData.hdr.fromIP, txFrame->source.vpnBytes.vpn, N_IPBYTES);

		memcpy(&spiTxBuffer->spiData.hdr.toCall, txFrame->dest.callbytes.callsign.bytes, N_CALL);
		memcpy(&spiTxBuffer->spiData.hdr.toIP, txFrame->dest.vpnBytes.vpn, N_IPBYTES);

		// flag fields: untouched by man or machine
		spiTxBuffer->spiData.hdr.coding = txFrame->flagfld.flags.coding;

		uint8_t frag = txFrame->flagfld.flags.fragmentation;

		// so payload related stuff
		uint8_t *payload = (uint8_t *)txFrame->buf;
		uint16_t length = txFrame->length;
		length += ((uint16_t)txFrame->flagfld.flags.payloadMSB) << 8;

		// extended calls
		if(txFrame->flagfld.flags.srcExt)	{
			memcpy(payload, (void *)&txFrame->srcExt, N_CALL);
			payload += N_CALL;
		}
		if(txFrame->flagfld.flags.destExt)	{
			memcpy(payload, (void *)&txFrame->destExt, N_CALL);
			payload += N_CALL;
		}
		// hop table
		if(txFrame->flagfld.flags.hoptable)	{
			SPI_HOPTABLE *hSPItable = (SPI_HOPTABLE *)payload;
			HOPTABLE *hIP400 = (HOPTABLE *)txFrame->hopTable;
			for(int i=0;i<MAX_HOPS;i++)	{
				hSPItable->hopEntry[i].callentry.callsign.encoded = hIP400->rptCalls[i].callbytes.callsign.encoded;
				hSPItable->hopEntry[i].flags = hIP400->flags[i];
			}
			payload += sizeof(SPI_HOPTABLE);
		}
		// remainder of payload
		memcpy(spiTxBuffer->spiData.buffer, payload, length);

		switch(frag)	{

			case FRAG_SELFCONTAINED:
				spiTxBuffer->spiData.hdr.offset_hi = 0;
				spiTxBuffer->spiData.hdr.offset_lo = 0;
				spiTxBuffer->spiData.hdr.length_lo = (uint8_t)length & 0xff;
				spiTxBuffer->spiData.hdr.length_hi = (uint8_t)(length >>8);
				spiTxBuffer->spiData.hdr.spiStat = SINGLE_FRAME;
				break;

			case FRAG_FIRST_FRAG:
				spiTxBuffer->spiData.hdr.offset_hi = 0;
				spiTxBuffer->spiData.hdr.offset_lo = 0;
				spiTxBuffer->spiData.hdr.length_lo = (uint8_t)length & 0xff;
				spiTxBuffer->spiData.hdr.length_hi = (uint8_t)(length >>8);
				spiTxBuffer->spiData.hdr.spiStat = FIRST_FRAGMENT;
				break;

			case FRAG_MIDDLE_FRAG:
				spiTxBuffer->spiData.hdr.offset_hi = (uint8_t)(SPI_BUFFER_LEN>>8);
				spiTxBuffer->spiData.hdr.offset_lo = (uint8_t)(SPI_BUFFER_LEN&0xFF);
				spiTxBuffer->spiData.hdr.length_lo = (uint8_t)length & 0xff;
				spiTxBuffer->spiData.hdr.length_hi = (uint8_t)(length >>8);
				spiTxBuffer->spiData.hdr.spiStat = MIDDLE_FRAGMENT;
				break;

			case FRAG_END_FRAG:
				spiTxBuffer->spiData.hdr.offset_hi = (uint8_t)((2*SPI_BUFFER_LEN)>>8);
				spiTxBuffer->spiData.hdr.offset_lo = (uint8_t)((2*SPI_BUFFER_LEN)&0xFF);
				spiTxBuffer->spiData.hdr.length_lo = (uint8_t)length & 0xff;
				spiTxBuffer->spiData.hdr.length_hi = (uint8_t)(length >>8);
				spiTxBuffer->spiData.hdr.spiStat = LAST_FRAGMENT;
				break;
		}

	}
}
