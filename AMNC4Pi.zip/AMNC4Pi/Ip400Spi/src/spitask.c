/*---------------------------------------------------------------------------
        Project:          Ip400Spi

        File Name:        spitask.c

        Author:           VE6VH

        Creation Date:    Mar. 6, 2025

        Description:      {Definition here...)

                          This program is free software: you can redistribute it and/or modify
                          it under the terms of the GNU General Public License as published by
                          the Free Software Foundation, either version 2 of the License, or
                          (at your option) any later version, provided this copyright notice
                          is included.

                          Copyright (c) 2024-25 Alberta Digital Radio Communications Society

---------------------------------------------------------------------------*/
#include <stdio.h>
#include <stdint.h>
#include <string.h>

#include "types.h"
#include "spidefs.h"
#include "logger.h"
#include "dataq.h"
#include "spi.h"
#include "nodesim.h"
#include "memory.h"

// locals
int spiDevFD;				// spi device file descriptor
int spiDevNum;				// device number

// frame buffers
static SPI_BUFFER spiTxBuffer;
static SPI_BUFFER spiRxBuffer;

static SPI_BUFFER fsmBuffer;

static union	{
	struct {
		struct spi_hdr_t	hdr;		// header
		uint8_t	buffer[PAYLOAD_MAX];
	} spiData;
	uint8_t	rawData[PAYLOAD_MAX + sizeof(struct spi_hdr_t)];
} rxFrameBuffer;

/*
 * queue a frame for transmission
 * Src frame is in static memory
 * queue struct and tx frame are in allocated memory
 */
/*
 * Initialize the SPI task
 */
BOOL spiTaskInit(int spiDev)
{
	// open the SPI device
	if(spiDev != UNDEFINED)		{
		if((spiDevFD = spi_open(spiDev)) == -1)	{
			logger(LOG_ERROR, "Unable to open SPI device %d\n", spiDev);
			return FALSE;
		}
	}

	fsmBuffer.spiData.hdr.spiStat = NO_FRAME;
	fsmBuffer.spiData.hdr.eye[0] = 'I';
	fsmBuffer.spiData.hdr.eye[1] = 'P';
	fsmBuffer.spiData.hdr.eye[2] = '4';
	fsmBuffer.spiData.hdr.eye[3] = 'C';

	spiTxBuffer.spiData.hdr.spiStat = NO_FRAME;
	spiTxBuffer.spiData.hdr.eye[0] = 'I';
	spiTxBuffer.spiData.hdr.eye[1] = 'P';
	spiTxBuffer.spiData.hdr.eye[2] = '4';
	spiTxBuffer.spiData.hdr.eye[3] = 'C';


	spiRxBuffer.spiData.hdr.spiStat = NO_FRAME;
	rxFrameBuffer.spiData.hdr.eye[0] = 'I';
	rxFrameBuffer.spiData.hdr.eye[1] = 'P';
	rxFrameBuffer.spiData.hdr.eye[2] = '4';
	rxFrameBuffer.spiData.hdr.eye[3] = 'C';

	logger(LOG_DEBUG, "Setup SPI exchange for %d bytes\n", SPI_RAW_LEN);

	nodeSimInit(&fsmBuffer);

	return TRUE;
}

/*
 * Run the SPI functions.
 * Poll receiver for an inbound frame and read it. Process the inbound frame
 * Poll transmit queue for an outbound frame and copy to tx buffer
 */
void spiTask(loopbackModes loopback)
{
	static SPI_FRAME_QUEUE *txFrame;
	int nxferred;

	memset(spiRxBuffer.rawData, 0, SPI_RAW_LEN);

	// check outbound first
	if((txFrame=getNextSpiFrame()) != NULL)	{
		memcpy(spiTxBuffer.rawData, txFrame->buffer, txFrame->length);
		nodeMemFree(SPI,txFrame->buffer);
		nodeMemFree(SPI,txFrame);
	}
	else spiTxBuffer.spiData.hdr.spiStat = NO_FRAME;

	// run the appropriate mode
	switch(loopback){

		case LOOP_SPI:
			// loopback spi code
			memcpy(spiRxBuffer.rawData, spiTxBuffer.rawData, SPI_RAW_LEN);
			nxferred = SPI_RAW_LEN;
			break;

		case LOOP_NODE:
			// simulation with node code: SPI receive will be in the spiRxBuffer
			nodeInterruptSim(&spiTxBuffer, SPI_RAW_LEN);
			if(runNodeFSM())	{
				memcpy(spiRxBuffer.rawData, fsmBuffer.rawData, SPI_RAW_LEN);
			}
			break;

		default:
			// do an exchange with the STM32
			nxferred = spi_fdtransfer(spiDevNum, spiTxBuffer.rawData, spiRxBuffer.rawData, SPI_RAW_LEN);
			if(nxferred == -1)	{
				logger(LOG_ERROR, "SPI transmit error %d: %s\n", nxferred, geterrno(nxferred));
			}
			break;
	}

	uint8_t rstat = spiRxBuffer.spiData.hdr.spiStat;

	// check frame status first
	if((rstat > NO_FRAME) && (rstat < N_STATUS))	{
		if(!isIP400Frame(spiRxBuffer.spiData.hdr.eye))	{
			logger(LOG_DEBUG, "Bad frame: Stat %d len %d, failed eye test %02X%02X%02X%02X\n",rstat,nxferred,
					spiRxBuffer.spiData.hdr.eye[0],
					spiRxBuffer.spiData.hdr.eye[1],
					spiRxBuffer.spiData.hdr.eye[2],
					spiRxBuffer.spiData.hdr.eye[3]);
		} else {
			process_SPI_Receive(&spiRxBuffer);
		}
	}
}

// validate the frame eye
BOOL isIP400Frame(uint8_t *eye)
{
	if((eye[0] != 'I') || (eye[1] != 'P'))
		return FALSE;

	if((eye[2] != '4') || (eye[3] != 'C'))
		return FALSE;

	return TRUE;

}
