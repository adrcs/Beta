/*---------------------------------------------------------------------------
        Project:          Ip400Spi

        File Name:        frame.c

        Author:           Martin, VE6VH

        Creation Date:    Dec. 5, 2025

        Description:      Handle fragmenting and reassembly of frames

                          This program is free software: you can redistribute it and/or modify
                          it under the terms of the GNU General Public License as published by
                          the Free Software Foundation, either version 2 of the License, or
                          (at your option) any later version, provided this copyright notice
                          is included.

                          Copyright (c) 2024-25 Alberta Digital Radio Communications Society

---------------------------------------------------------------------------*/
#include <stdio.h>
#include <string.h>

#include "types.h"
#include "logger.h"
#include "spidefs.h"
#include "dataq.h"
#include "memory.h"

// local defines
#define	MAX_ONAIR_PAYLOAD	900			// max sizeof(payload)
#define	N_SPLIT_FRAMES		2			// max number of split frames

// fwd refs: send a frame to the SPI
void sendSingleFrame(UDP_FRAME *rx_frame, int payloadlen, spiFrameStatus status);
void sendFragmentedFrame(UDP_FRAME *rx_frame, int payloadLen, int baseoffset, spiFrameStatus status);

UDP_FRAME		tx_frame;				// transmit frame

// UDP Rx Queue
FRAME_QUEUE	UDPRxQueue;

// SPI transmit frame queue
FRAME_QUEUE	SPITxQueue;

// fwd refs
void process_UDP_Receive(UDP_FRAME *rx_frame, int payloadlen);

/*
 * initialize the payload task
 */
void initFrameQueues(void)
{
	// init the tx queue
	SPITxQueue.q_forw = &SPITxQueue;
	SPITxQueue.q_back = &SPITxQueue;

	UDPRxQueue.q_forw = &UDPRxQueue;
	UDPRxQueue.q_back = &UDPRxQueue;
}

/*
 * get the next frame for the SPI
 * pick off the SPI queue first, as it may contain fragments
 * if empty, try the UDP queue next
 */
SPI_FRAME_QUEUE *getNextSpiFrame(void)
{
	SPI_FRAME_QUEUE *spiframe;
	FRAME_QUEUE *qframe;
	UDP_FRAME *udpframe;

	// loop in case there is more work to do
	while(TRUE)	{

		// empty frame transmit queue
		if((spiframe=dequeFrame(&SPITxQueue)) != NULL)
			return spiframe;

		// spi queue is empty; check inbound UDP
		if((qframe=dequeFrame(&UDPRxQueue)) != NULL)	{
			udpframe = qframe->data;
			process_UDP_Receive(udpframe, qframe->length);
			nodeMemFree(UDP, qframe->data);
			nodeMemFree(UDP, qframe);
		} else {
			return NULL;		// nothing queued
		}
	}
}

/*
 * Queue up a UDP frame
 * frame is in allocated memory
 */
BOOL EnqueUDPFrame(UDP_FRAME *rxFrame, int length)
{
	FRAME_QUEUE *qFrame;

	// malloc memory for the queue entry: data is already malloced
	if((qFrame=nodeMemAlloc(UDP,sizeof(FRAME_QUEUE))) == NULL)
		return FALSE;

	qFrame->data = rxFrame;
	qFrame->length = length;

	if(!enqueFrame(&UDPRxQueue, qFrame, 0))	{
		free(qFrame->data);
		free(qFrame);
		return FALSE;
	}

	return TRUE;
}

/*
 * queue a frame for transmission
 * Src frame is in static memory
 * queue struct and tx frame are in allocated memory
 */
BOOL EnqueSPIFrame(SPI_FRAME_QUEUE *SrcFrame)
{
	SPI_FRAME_QUEUE *qFrame;
	UDP_FRAME *frameBuffer;

	// malloc memory for the frame data
	if((qFrame=nodeMemAlloc(SPI, sizeof(SPI_FRAME_QUEUE))) == NULL)
		return FALSE;
	memcpy(qFrame, SrcFrame, sizeof(SPI_FRAME_QUEUE));

	// alloc the data portion of the frame
	if((frameBuffer=(UDP_FRAME *)nodeMemAlloc(SPI, SrcFrame->length)) == NULL)	{
		free(qFrame);
		return FALSE;
	}

	memcpy(frameBuffer, (uint8_t *)SrcFrame->buffer, SrcFrame->length);
	qFrame->buffer = frameBuffer;
	qFrame->length = SrcFrame->length;

	if(!enqueFrame(&SPITxQueue, qFrame, 0))	{
		nodeMemFree(SPI,qFrame);
		nodeMemFree(SPI,frameBuffer);
		return FALSE;
	}
	return TRUE;
}

/*
 * process a UDP packet into SPI frames
 * Four cases:
 * 	1) It fits in one SPI buffer
 * 	2) Fragmented; but fits in one on-air packet
 * 	3) Split frame; fragmented and remainder in one SPI
 * 	4) Split frame; both fragmented
 */

void process_UDP_Receive(UDP_FRAME *rx_frame, int payloadlen)
{

	// case 1: frame fits in a single buffer
	if(payloadlen <= SPI_BUFFER_LEN)	{
		sendSingleFrame(rx_frame, payloadlen, SINGLE_FRAME);
		return;
	}

	int currLen = payloadlen;
	int status = FIRST_FRAGMENT;
	int baseoffset = 0;
	int frameLen = SPI_BUFFER_LEN;

	// send first fragment
	sendFragmentedFrame(rx_frame, frameLen, baseoffset, status);
	baseoffset += frameLen;
	currLen -= frameLen;

	// middle fragment
	if(currLen > SPI_BUFFER_LEN)	{
		status = MIDDLE_FRAGMENT;
		memcpy(rx_frame->spiData.data, &rx_frame->spiData.data[baseoffset], frameLen);
		sendFragmentedFrame(rx_frame, frameLen, baseoffset, status);
		baseoffset += frameLen;
		currLen -= frameLen;
	}

	// final fragment
	memcpy(rx_frame->spiData.data, &rx_frame->spiData.data[baseoffset], currLen);
	status = LAST_FRAGMENT;
	sendFragmentedFrame(rx_frame, currLen, baseoffset, status);

}

// send a single frame
void sendSingleFrame(UDP_FRAME *rx_frame, int payloadlen, spiFrameStatus status)
{
	SPI_FRAME_QUEUE spiQueue;

	rx_frame->spiData.hdr.spiStat = status;
	rx_frame->spiData.hdr.length_hi = (uint8_t)(payloadlen>>8);
	rx_frame->spiData.hdr.length_lo = (uint8_t)(payloadlen&0xFF);
	rx_frame->spiData.hdr.offset_hi = (uint8_t)0;
	rx_frame->spiData.hdr.offset_lo = (uint8_t)0;
	rx_frame->spiData.hdr.spiStat = SINGLE_FRAME;
	spiQueue.buffer = rx_frame;
	spiQueue.length = payloadlen + sizeof(SPI_HEADER);
	EnqueSPIFrame(&spiQueue);
	logger(LOG_DEBUG, "Sending single frame of %d bytes, %s\n", payloadlen, formatHeader(rx_frame));
}

// send a buffer as a fragmented frame
void sendFragmentedFrame(UDP_FRAME *rx_frame, int payloadLen, int baseoffset, spiFrameStatus status)
{
	SPI_FRAME_QUEUE spiQueue;

	// send the first SPI buffer full
	rx_frame->spiData.hdr.spiStat = status;
	rx_frame->spiData.hdr.length_hi = (uint8_t)(payloadLen>>8);
	rx_frame->spiData.hdr.length_lo = (uint8_t)(payloadLen&0xFF);
	rx_frame->spiData.hdr.offset_hi = (uint8_t)(baseoffset>>8);
	rx_frame->spiData.hdr.offset_lo = (uint8_t)(baseoffset&0xFF);
	spiQueue.buffer = rx_frame;
	spiQueue.length = payloadLen + sizeof(SPI_HEADER);
	EnqueSPIFrame(&spiQueue);
	logger(LOG_DEBUG, "Sending fragment %d of %d bytes, %s\n", status, payloadLen, formatHeader(rx_frame));

}

// format the header for debug purposes
char *formatHeader(void *f)
{
	UDP_FRAME *fr = (UDP_FRAME *)f;

	static char prtBuf[200], pB[100];

	char *p = strncpy(prtBuf, (const char *)fr->spiData.hdr.eye, 4);
	*p = '\0';
	sprintf(pB, " Stat: %d", fr->spiData.hdr.spiStat);
	strcat(prtBuf, pB);
	sprintf(pB, " L: %d", ((((uint16_t)fr->spiData.hdr.length_hi)<<8) + (uint16_t)fr->spiData.hdr.length_lo));
	strcat(prtBuf, pB);

	return prtBuf;
}

/*
 * process a received SPI buffer. Can take up to 4 SPI exchanges
 * four cases:
 * 	1) Self-contained
 * 	2) Single frame; less than max on air, fragmented
 * 	3) Split frame, fragmented + single
 * 	4) Split frame, fragmented + fragmented
 */
BOOL process_SPI_Receive(SPI_BUFFER *rxBuffer)
{

	int splitOffset;

	int payloadLen = ((int)rxBuffer->spiData.hdr.length_hi);
	payloadLen = (payloadLen << 8) + rxBuffer->spiData.hdr.length_lo;

	int offset = rxBuffer->spiData.hdr.offset_hi;
	offset = (offset << 8) + rxBuffer->spiData.hdr.offset_lo;

	int rawFrameLen = payloadLen + sizeof(SPI_HEADER);

	spiFrameStatus Status = (spiFrameStatus)rxBuffer->spiData.hdr.spiStat;

	switch(Status)	{

		case SINGLE_FRAME:
			memcpy(tx_frame.rawData, rxBuffer->rawData, rawFrameLen);
			return send_udp_packet(tx_frame.rawData, rawFrameLen);
			break;

		case FIRST_FRAGMENT:
			memcpy(tx_frame.rawData, rxBuffer->rawData, payloadLen + sizeof(SPI_HEADER));
			tx_frame.spiData.hdr.offset_hi = (payloadLen>>8);
			tx_frame.spiData.hdr.offset_lo = (payloadLen&0xFF);
			break;

		case MIDDLE_FRAGMENT:
			splitOffset = tx_frame.spiData.hdr.offset_hi;
			splitOffset = (splitOffset << 8) + tx_frame.spiData.hdr.offset_lo;
			memcpy(&tx_frame.spiData.data[splitOffset], rxBuffer->spiData.buffer, payloadLen);
			splitOffset += payloadLen;
			// last fragment if payload does not extend to SPI_BUFFER_LEN
			if(payloadLen < SPI_BUFFER_LEN)		{
				tx_frame.spiData.hdr.offset_hi = 0;
				tx_frame.spiData.hdr.offset_lo = 0;
				tx_frame.spiData.hdr.length_hi = (uint8_t)(splitOffset>>8);
				tx_frame.spiData.hdr.length_lo = (uint8_t)(splitOffset&0xFF);
				tx_frame.spiData.hdr.spiStat = SINGLE_FRAME;
				return send_udp_packet(tx_frame.rawData, splitOffset + sizeof(SPI_HEADER));

			} else {
				tx_frame.spiData.hdr.offset_hi = (splitOffset>>8);
				tx_frame.spiData.hdr.offset_lo = (splitOffset&0xFF);
			}
			break;

		case LAST_FRAGMENT:
			splitOffset = tx_frame.spiData.hdr.offset_hi;
			splitOffset = (splitOffset << 8) + tx_frame.spiData.hdr.offset_lo;
			memcpy(&tx_frame.spiData.data[splitOffset], rxBuffer->spiData.buffer, payloadLen);
			splitOffset += payloadLen;
			tx_frame.spiData.hdr.offset_hi = 0;
			tx_frame.spiData.hdr.offset_lo = 0;
			tx_frame.spiData.hdr.length_hi = (uint8_t)(splitOffset>>8);
			tx_frame.spiData.hdr.length_lo = (uint8_t)(splitOffset&0xFF);
			tx_frame.spiData.hdr.spiStat = SINGLE_FRAME;
			return send_udp_packet(tx_frame.rawData, splitOffset + sizeof(SPI_HEADER));

		default:
			break;
	}
	return TRUE;
}
