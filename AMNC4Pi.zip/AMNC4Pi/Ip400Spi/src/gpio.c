/*---------------------------------------------------------------------------
        Project:          Ip400Spi

        File Name:        gpio.c

        Author:           root

        Creation Date:    Nov. 4, 2025

        Description:      Code to write GPIO. Extracted from stm32flash.h

                          This program is free software: you can redistribute it and/or modify
                          it under the terms of the GNU General Public License as published by
                          the Free Software Foundation, either version 2 of the License, or
                          (at your option) any later version, provided this copyright notice
                          is included.

                          Copyright (c) 2024-25 Alberta Digital Radio Communications Society

---------------------------------------------------------------------------*/
#include <ctype.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <sys/stat.h>

#include "gpio.h"
#include "logger.h"

#define	SLEEP_TIME			10000			// sleep between operations

// internals
GPIOStatus write_to(const char *filename, const char *value);
GPIOStatus read_from(const char *filename, char *buf, size_t len);
GPIOStatus drive_gpio(int n, GPIOLevel level);
GPIOStatus release_gpio(int n);

/*
 * reset the mini-node
 */
GPIOStatus gpio_reset(int gpioNum)
{
	// set high first
	fprintf(stderr, "Setting gpio %i high...", gpioNum);
	if(drive_gpio(gpioNum, GPIO_LEVEL_HIGH) != GPIO_OK)
		return GPIO_ERR;
	usleep(SLEEP_TIME);

	// set low
	fprintf(stderr, "setting gpio %i low...", gpioNum);
	if(drive_gpio(gpioNum, GPIO_LEVEL_LOW) != GPIO_OK)
		return GPIO_ERR;
	usleep(SLEEP_TIME);

	// set high again
	fprintf(stderr, "setting gpio %i high...", gpioNum);
	if(drive_gpio(gpioNum, GPIO_LEVEL_HIGH) != GPIO_OK)
		return GPIO_ERR;
	usleep(SLEEP_TIME);

	fprintf(stderr, "releasing GPIO\n");
	return release_gpio(gpioNum);
}

// read from a file
GPIOStatus write_to(const char *filename, const char *value)
{
	int fd, ret;

	fd = open(filename, O_WRONLY);
	if (fd < 0) {
		fprintf(stderr, "Cannot open file \"%s\"\n", filename);
		return GPIO_ERR;
	}
	ret = write(fd, value, strlen(value));
	if (ret < 0) {
		fprintf(stderr, "Error %d writing %s to file \"%s\" (%s)\n", errno, value, filename, geterrno(errno));
		close(fd);
		return GPIO_ERR;
	}
	close(fd);
	return GPIO_OK;
}

// write to a file
GPIOStatus read_from(const char *filename, char *buf, size_t len)
{
	int fd, ret;
	size_t n = 0;

	fd = open(filename, O_RDONLY);
	if (fd < 0) {
		fprintf(stderr, "Cannot open file \"%s\"\n", filename);
		return 0;
	}

	do {
		ret = read(fd, buf + n, len - n);
		if (ret < 0) {
			if (errno == EINTR || errno == EAGAIN || errno == EWOULDBLOCK)
				continue; /* try again */
			fprintf(stderr, "Error reading file \"%s\"\n", filename);
			close(fd);
			return GPIO_ERR;
		}
		n += ret;
	} while (n < len && ret);

	close(fd);
	return n;
}

// Drive a GPIO to a specific level
GPIOStatus drive_gpio(int n, GPIOLevel level)
{
	char num[16]; /* sized to carry MAX_INT */
	char file[48]; /* sized to carry longest filename */
	struct stat buf;
	int ret;

	sprintf(file, "/sys/class/gpio/gpio%d/value", n);
	ret = stat(file, &buf);
	if (ret) {
		/* file miss, GPIO not exported yet */
		sprintf(num, "%d", n);
		ret = write_to("/sys/class/gpio/export", num);
		if (!ret)	{
			logger(LOG_ERROR, "Write to export pin failed: %d, %s\n", ret, geterrno(errno));
			return GPIO_ERR;
		}
		ret = stat(file, &buf);
		if (ret) {
			logger(LOG_ERROR, "GPIO %d not available: %s\n", n, geterrno(errno));
			return GPIO_ERR;
		}
		/* give udevd a chance to set permissions */
		if (access(file, W_OK))
			usleep(10);
	}

	sprintf(file, "/sys/class/gpio/gpio%d/direction", n);

	/*	do nothing code left over
 	char dir;
	ret = stat(file, &buf);
	if (!ret)
		if (read_from(file, &dir, sizeof(dir)))
			if (dir == 'i')
				input = 1;
	 */
	return write_to(file, level ? "high" : "low");
}

// release an exported GPIO
GPIOStatus release_gpio(int n)
{
	char num[16]; /* sized to carry MAX_INT */

	sprintf(num, "%d", n);
	write_to("/sys/class/gpio/unexport", num);

	return GPIO_OK;
}
