/*---------------------------------------------------------------------------
        Project:          Ip400Spi

        File Name:        memory.c

        Author:           root

        Creation Date:    Mar. 11, 2026

        Description:      {Definition here...)

                          This program is free software: you can redistribute it and/or modify
                          it under the terms of the GNU General Public License as published by
                          the Free Software Foundation, either version 2 of the License, or
                          (at your option) any later version, provided this copyright notice
                          is included.

                          Copyright (c) 2024-25 Alberta Digital Radio Communications Society

---------------------------------------------------------------------------*/
#include <malloc.h>

#include "memory.h"

// memory stats & allocation routines
int nAllocs[N_MEM_ALLOCS] =
		{
			0, 0, 0, 0, 0, 0, 0
		};

char *modules[] = {
		"Chat",
		"Data Q",
		"Frame",
		"Kiss",
		"SPI",
		"SUBG",
		"OTHERS"
};


/*
 * Memory allocators/deallocators
 */
void *nodeMemAlloc(int module, size_t size)
{
	nAllocs[module]++;
	return malloc(size);
}

void nodeMemFree(int module, void *mem)
{
	nAllocs[module]--;
	free(mem);
}
