#!/bin/bash

if [ "$#" -ne 1 ]; then
	echo "Usage ip400flash <filename>"
	exit 100
fi

set -x
echo "********************************************************"
echo "                  AMNC Cpu Flash Script                *"
echo "                     Flashing $1                       *"
echo "********************************************************"

#Notes: GPIO 24 is nreset
#	GPIO 25 is boot ena
nreset=24
bootena=25

pinctrl set $bootena op dh
sleep .1
pinctrl set $nreset op dl
sleep .1
pinctrl set $nreset op dh
sleep .1
# program flash
#/usr/local/bin/stm32flash -b 115200 -i $bootena,-$nreset,$nreset:-$bootena,$nreset /dev/ttyAMA0
/usr/local/bin/stm32flash -b 115200  -v -w "$1" -g 0x0 -R /dev/serial0
#
sleep .1
pinctrl set $bootena op dl
sleep .1
pinctrl set $nreset op dl
sleep .1
pinctrl set $nreset op dh
sleep .1
set +x
